const virtex = (pushname, prefix, botName, ownerName, getLevelingLevel, sender, _registered, uangku) => {
	return `࿐🌈MANIK JB🌈࿐ 
NTAR BOT IKUT NGELEG PANTEK
exports.virtex = virtex
